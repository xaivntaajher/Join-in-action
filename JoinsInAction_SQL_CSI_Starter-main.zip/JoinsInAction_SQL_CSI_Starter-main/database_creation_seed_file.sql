CREATE DATABASE movies_library;

CREATE TABLE IF NOT EXISTS movies_library.movies(
   movie_id               INTEGER  NOT NULL PRIMARY KEY
  ,film             VARCHAR(35) NOT NULL
  ,genre            VARCHAR(9) NOT NULL
  ,lead_studio      VARCHAR(21) NOT NULL
  ,audience_score  INTEGER  NOT NULL
  ,profitability    NUMERIC(11,9) NOT NULL
  ,rotten_tomatoes INTEGER  NOT NULL
  ,worldwide_gross  VARCHAR(8) NOT NULL
  ,year             INTEGER  NOT NULL
);

CREATE TABLE IF NOT EXISTS movies_library.users(
   user_id                INTEGER  NOT NULL PRIMARY KEY
  ,first_name        VARCHAR(255) NOT NULL
  ,last_name         VARCHAR(255) NOT NULL
  ,favorite_movie_id INTEGER NULL
  ,FOREIGN KEY (favorite_movie_id) REFERENCES movies_library.movies(movie_id)
);


INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (1,'Youth in Revolt','Comedy','The Weinstein Company',52,1.09,68,'$19.62',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (2,'You Will Meet a Tall Dark Stranger','Comedy','Independent',35,1.21,43,'$26.66',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (3,'When in Rome','Comedy','Disney',44,0,15,'$43.04',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (4,'What Happens in Vegas','Comedy','Fox',72,6.267647029,28,'$219.37',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (5,'Water For Elephants','Drama','20th Century Fox',72,3.081421053,60,'$117.09',2011);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (6,'WALL-E','Animation','Disney',89,2.896019067,96,'$521.28',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (7,'Waitress','Romance','Independent',67,11.0897415,89,'$22.18',2007);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (8,'Waiting For Forever','Romance','Independent',53,0.005,6,'$0.03',2011);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (9,'Valentine''s Day','Comedy','Warner Bros.',54,4.184038462,17,'$217.57',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (10,'Tyler Perry''s Why Did I get Married','Romance','Independent',47,3.7241924,46,'$55.86',2007);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (11,'Twilight: Breaking Dawn','Romance','Independent',68,6.383363636,26,'$702.17',2011);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (12,'Twilight','Romance','Summit',82,10.18002703,49,'$376.66',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (13,'The Ugly Truth','Comedy','Independent',68,5.402631579,14,'$205.30',2009);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (14,'The Twilight Saga: New Moon','Drama','Summit',78,14.1964,27,'$709.82',2009);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (15,'The Time Traveler''s Wife','Drama','Paramount',65,2.598205128,38,'$101.33',2009);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (16,'The Proposal','Comedy','Disney',74,7.8675,43,'$314.70',2009);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (17,'The Invention of Lying','Comedy','Warner Bros.',47,1.751351351,56,'$32.40',2009);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (18,'The Heartbreak Kid','Comedy','Paramount',41,2.129444167,30,'$127.77',2007);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (19,'The Duchess','Drama','Paramount',68,3.207850222,60,'$43.31',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (20,'The Curious Case of Benjamin Button','Fantasy','Warner Bros.',81,1.78394375,73,'$285.43',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (21,'The Back-up Plan','Comedy','CBS',47,2.202571429,20,'$77.09',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (22,'Tangled','Animation','Disney',88,1.365692308,89,'$355.01',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (23,'Something Borrowed','Romance','Independent',48,1.719514286,15,'$60.18',2011);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (24,'She''s Out of My League','Comedy','Paramount',60,2.4405,57,'$48.81',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (26,'Sex and the City 2','Comedy','Warner Bros.',49,2.8835,15,'$288.35',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (27,'Sex and the City','Comedy','Warner Bros.',81,7.221795791,49,'$415.25',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (28,'Remember Me','Drama','Summit',70,3.49125,28,'$55.86',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (29,'Rachel Getting Married','Drama','Independent',61,1.384166667,85,'$16.61',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (30,'Penelope','Comedy','Summit',74,1.382799733,52,'$20.74',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (31,'P.S. I Love You','Romance','Independent',82,5.103116833,21,'$153.09',2007);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (32,'Over Her Dead Body','Comedy','New Line',47,2.071,15,'$20.71',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (33,'Our Family Wedding','Comedy','Independent',49,0,14,'$21.37',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (34,'One Day','Romance','Independent',54,3.682733333,37,'$55.24',2011);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (35,'Not Easily Broken','Drama','Independent',66,2.14,34,'$10.70',2009);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (36,'No Reservations','Comedy','Warner Bros.',64,3.307180357,39,'$92.60',2007);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (37,'Nick and Norah''s Infinite Playlist','Comedy','Sony',67,3.3527293,73,'$33.53',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (38,'New Year''s Eve','Romance','Warner Bros.',48,2.536428571,8,'$142.04',2011);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (39,'My Week with Marilyn','Drama','The Weinstein Company',84,0.8258,83,'$8.26',2011);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (40,'Music and Lyrics','Romance','Warner Bros.',70,3.64741055,63,'$145.90',2007);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (41,'Monte Carlo','Romance','20th Century Fox',50,1.9832,38,'$39.66',2011);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (42,'Miss Pettigrew Lives for a Day','Comedy','Independent',70,0.2528949,78,'$15.17',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (43,'Midnight in Paris','Romence','Sony',84,8.744705882,93,'$148.66',2011);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (44,'Marley and Me','Comedy','Fox',77,3.746781818,63,'$206.07',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (45,'Mamma Mia!','Comedy','Universal',76,9.234453864,53,'$609.47',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (46,'Mamma Mia!','Comedy','Universal',76,9.234453864,53,'$609.47',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (47,'Made of Honor','Comdy','Sony',61,2.64906835,13,'$105.96',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (48,'Love Happens','Drama','Universal',40,2.004444444,18,'$36.08',2009);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (49,'Love & Other Drugs','Comedy','Fox',55,1.817666667,48,'$54.53',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (50,'Life as We Know It','Comedy','Independent',62,2.530526316,28,'$96.16',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (51,'License to Wed','Comedy','Warner Bros.',55,1.9802064,8,'$69.31',2007);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (52,'Letters to Juliet','Comedy','Summit',62,2.639333333,40,'$79.18',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (53,'Leap Year','Comedy','Universal',49,1.715263158,21,'$32.59',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (54,'Knocked Up','Comedy','Universal',83,6.636401848,91,'$219',2007);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (55,'Killers','Action','Lionsgate',45,1.245333333,11,'$93.40',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (56,'Just Wright','Comedy','Fox',58,1.797416667,45,'$21.57',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (57,'Jane Eyre','Romance','Universal',77,0,85,'$30.15',2011);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (58,'It''s Complicated','Comedy','Universal',63,2.642352941,56,'$224.60',2009);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (59,'I Love You Phillip Morris','Comedy','Independent',57,1.34,71,'$20.10',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (60,'High School Musical 3: Senior Year','Comedy','Disney',76,22.91313646,65,'$252.04',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (61,'He''s Just Not That Into You','Comedy','Warner Bros.',60,7.1536,42,'$178.84',2009);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (62,'Good Luck Chuck','Comedy','Lionsgate',61,2.36768512,3,'$59.19',2007);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (63,'Going the Distance','Comedy','Warner Bros.',56,1.3140625,53,'$42.05',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (64,'Gnomeo and Juliet','Animation','Disney',52,5.387972222,56,'$193.97',2011);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (65,'Gnomeo and Juliet','Animation','Disney',52,5.387972222,56,'$193.97',2011);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (66,'Ghosts of Girlfriends Past','Comedy','Warner Bros.',47,2.0444,27,'$102.22',2009);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (67,'Four Christmases','Comedy','Warner Bros.',52,2.022925,26,'$161.83',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (68,'Fireproof','Drama','Independent',51,66.934,40,'$33.47',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (69,'Enchanted','Comedy','Disney',80,4.005737082,93,'$340.49',2007);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (70,'Dear John','Drama','Sony',66,4.5988,29,'$114.97',2010);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (71,'Beginners','Comedy','Independent',80,4.471875,84,'$14.31',2011);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (72,'Across the Universe','romance','Independent',84,0.652603178,54,'$29.37',2007);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (73,'A Serious Man','Drama','Universal',64,4.382857143,89,'$30.68',2009);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (74,'A Dangerous Method','Drama','Independent',89,0.44864475,79,'$8.97',2011);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (75,'27 Dresses','Comedy','Fox',71,5.3436218,40,'$160.31',2008);
INSERT INTO movies_library.movies(movie_id,film,genre,lead_studio,audience_score,profitability,rotten_tomatoes,worldwide_gross,year) VALUES (76,'(500) Days of Summer','comedy','Fox',81,8.096,87,'$60.72',2009);

INSERT INTO movies_library.users(user_id,first_name,last_name,favorite_movie_id) VALUES (1,'Susan','Wood',5);
INSERT INTO movies_library.users(user_id,first_name,last_name,favorite_movie_id) VALUES (2,'Serenity','Mccarthy',38);
INSERT INTO movies_library.users(user_id,first_name,last_name,favorite_movie_id) VALUES (3,'Reem','Mackie',14);
INSERT INTO movies_library.users(user_id,first_name,last_name,favorite_movie_id) VALUES (4,'Tobey','Fuentes',NULL);
INSERT INTO movies_library.users(user_id,first_name,last_name,favorite_movie_id) VALUES (5,'Alysha','Tierney',16);
INSERT INTO movies_library.users(user_id,first_name,last_name,favorite_movie_id) VALUES (6,'Joanna','Michael',28);
INSERT INTO movies_library.users(user_id,first_name,last_name,favorite_movie_id) VALUES (7,'Rahul','Murray',76);
INSERT INTO movies_library.users(user_id,first_name,last_name,favorite_movie_id) VALUES (8,'Coen','Escobar',1);
INSERT INTO movies_library.users(user_id,first_name,last_name,favorite_movie_id) VALUES (9,'Sakina','Allen', NULL);
INSERT INTO movies_library.users(user_id,first_name,last_name,favorite_movie_id) VALUES (10,'Arian','Kaufman',74);
INSERT INTO movies_library.users(user_id,first_name,last_name,favorite_movie_id) VALUES (11,'Shelbie','Singleton',43);
INSERT INTO movies_library.users(user_id,first_name,last_name,favorite_movie_id) VALUES (12,'Ishika','Hope',64);
INSERT INTO movies_library.users(user_id,first_name,last_name,favorite_movie_id) VALUES (13,'Theodore','Cain',6);
INSERT INTO movies_library.users(user_id,first_name,last_name,favorite_movie_id) VALUES (14,'Caden','Dunlap',32);
INSERT INTO movies_library.users(user_id,first_name,last_name,favorite_movie_id) VALUES (15,'Ann','Mustafa',3);
INSERT INTO movies_library.users(user_id,first_name,last_name,favorite_movie_id) VALUES (16,'Troy','Taylor',65);